#define MajorVer 0
#define MinorVer 9
#define PatchVer 13
#define Suffix ""
#define BuildVer 20140617
#define BuildVerStr "20140617"
#define VersionString "0.9.13 Build 20140617"
#define MyAppName "rec_robotino_api2"
#define MyAppExeName ""
#define MyCompany      "REC GmbH"
#define MyPublisherURL "www.servicerobotics.eu"
#define MySupportURL   "www.servicerobotics.eu"
#define MyUpdatesURL   "www.servicerobotics.eu"
